# Pygmy Test Settings
PYGMY_API_ADDRESS = 'http://127.0.0.1:9118'

PYGMY_API_AUTH = 'BasicAuth'

PYGMY_API_USER = 'admin'

PYGMY_API_PASSWORD = 'admin'

HOSTNAME = '127.0.0.1:8001'
