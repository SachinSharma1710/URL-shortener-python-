"""Pygmy configuration package."""

from pygmy.config.config import Configuration


config = Configuration()
