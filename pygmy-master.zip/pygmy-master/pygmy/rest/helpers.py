"""Rest API helper functions"""

