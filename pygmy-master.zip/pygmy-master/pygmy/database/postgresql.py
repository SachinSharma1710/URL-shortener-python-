from pygmy.database.base import BaseDatabase


class PostgreSQLDatabase(BaseDatabase):
    pass
