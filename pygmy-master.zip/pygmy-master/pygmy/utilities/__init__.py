"""Contains utility functions"""
